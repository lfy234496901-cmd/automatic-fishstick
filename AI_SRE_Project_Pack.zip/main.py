import json
import time

# --- Tools (Simulated) ---
def fetch_logs(service_name):
    print(f"🔧 [Tool] Fetching logs for {service_name}...")
    return "[ERROR] java.lang.OutOfMemoryError: Java heap space"

def check_metrics(service_name):
    print(f"🔧 [Tool] Checking metrics for {service_name}...")
    return '{"memory": "98%", "status": "critical"}'

def execute_k8s_restart(pod_name):
    print(f"⚠️ [Action] Restarting pod {pod_name}...")
    return "SUCCESS: Pod restarted."

# --- Mock LLM ---
class MockLLM:
    def generate(self, prompt):
        if "Watcher" in prompt: return '{"action": "investigate", "service": "payment-service"}'
        if "Investigator" in prompt: return "RCA: OOM identified. Recommendation: Restart."
        if "Action" in prompt: return '{"cmd": "restart", "target": "payment-pod-abc"}'
        return "{}"

# --- Agents ---
class WatcherAgent:
    def __init__(self, llm): self.llm = llm
    def run(self, alert):
        print(f"👀 [Watcher] Alert received: {alert['title']}")
        return json.loads(self.llm.generate(f"Watcher: {alert}"))

class InvestigatorAgent:
    def __init__(self, llm): self.llm = llm
    def run(self, svc):
        print(f"🕵️‍♂️ [Investigator] Investigating {svc}...")
        logs, metrics = fetch_logs(svc), check_metrics(svc)
        return self.llm.generate(f"Investigator: {logs}, {metrics}")

class ActionAgent:
    def __init__(self, llm): self.llm = llm
    def run(self, rca):
        print("🛠️ [Action] Planning remediation...")
        plan = json.loads(self.llm.generate(f"Action: {rca}"))
        if plan.get("cmd") == "restart": return execute_k8s_restart(plan["target"])
        return "Manual intervention needed."

# --- Workflow ---
def main():
    llm = MockLLM()
    alert = {"title": "Payment Service Latency High"}
    
    decision = WatcherAgent(llm).run(alert)
    if decision["action"] == "investigate":
        rca = InvestigatorAgent(llm).run(decision["service"])
        status = ActionAgent(llm).run(rca)
        print(f"✅ Final Status: {status}")

if __name__ == "__main__":
    main()
