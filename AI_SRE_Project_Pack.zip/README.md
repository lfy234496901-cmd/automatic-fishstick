# AI-SRE: Multi-Agent Fault Diagnosis & Self-Healing System

## 📌 Project Overview
This project is an LLM-driven multi-agent collaborative system designed to automate production incident handling in cloud-native environments. It mimics the SRE workflow: **Observe -> Diagnose -> Heal**.

## 🚀 Core Architecture (Multi-Agent)
1. **Watcher Agent**: Monitors alerts (Prometheus/PagerDuty), extracts context, and triggers investigations.
2. **Investigator Agent**: The "Brain". Uses **Chain-of-Thought (CoT)** and **Tool Calling** to fetch logs/metrics and output a Root Cause Analysis (RCA).
3. **Action Agent**: Evaluates risks and executes remediation (e.g., K8s restarts) or flags for human approval.

## 🛠️ Tech Stack
- **Python 3.10+**
- **LLM**: Mocked logic (Ready for OpenAI/Gemini API integration)
- **Framework**: ReAct-based Agent Orchestration

## 📂 File Structure
- `main.py`: Core logic and Agent definitions.
- `requirements.txt`: Project dependencies.
- `.gitignore`: Standard git exclusion rules.
- `README.md`: Documentation.

## 📝 How to Run
```bash
python main.py
```
